<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>BUSCAR cep</title>


		
</head>


<body style="background-color: #064169;">

<nav class="navbar navbar-light" style="background-color: #0c2239;">

<div>
	<img src="AppsGoogleMaps.png" width="40" height="40" alt="">
	<span class="navbar-brand mb-0 h1 text-light">Ache sua busca.</span>
	<span class=" text-center navbar-brand mb-0 h1 text-warning  font-italic">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Procure e encontre CEPS de todo o Brasil
	</span>
</div>
</nav>


	<!--Formulário buscador CEP-->
	<div class="row m-1 pb-1">
          <div class="column">
             <form action="index.php">
	 				  
	 				  <div style="display: flex;">
	 				     <input name="_cep" type="text" class="form-control" placeholder="Digite o CEP">


                <div class="d-flex flex-row">
        	          <button class="btn btn-info btn-block" type="submit">Buscar</button>
        	       </div>
        	    </div>
	       </form>
         </div>
		  
        
	      </div>
	    </div>
	</div>


	
	<div>
		   <div class=" justify-content-center d-flex flex-row bd-highlight mb-3">
  				<div class=" text-light font-weight-bold h3" >CEP:&nbsp;</div>
  				<div class=" text-light font-weight-bold h3" id="demo_cep_tela"></div>

  				
		   </div>
<div class=" justify-content-center d-flex flex-row 
bd-highlight mb-3" >
	
	<div id="demo_logradouro_tela" class="text-light"></div>
	<div class="text-light">&nbsp;-&nbsp;</div>
	<div class="text-light" id="demo_uf_tela"></div>
</div>

		
		
	
	</div>

<div class=" bg-light border  border-primary container" style="display: flex;">
	<div style="flex: 1;">

		<div class="d-flex flex-row">
			<div class="font-weight-bold">&nbsp;Logradouro:&nbsp;</div>
			<div id="demo_logradouro"></div>
		</div >
		
		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;CEP:&nbsp;</div>
			<div id="demo_cep"></div>
		</div>
		
		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;Bairro:&nbsp;</div>
			<div id="demo_bairro"></div>
		</div>

		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;Complemento:&nbsp;</div>
			<div id="demo_complemento"> --- </div>
		</div>
	
	<!---->
	</div>
   <!--fim div Flex: 1;-->

	<div style="flex: 2;">
		
		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;Localidade:&nbsp;</div>
			<div id="demo_localidade"></div>
		</div>

		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;DDD:&nbsp;</div>
			<div id="demo_ddd"></div>
		</div>

		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;IBGE:&nbsp;</div>
			<div id="demo_ibge"></div>
		</div>

		<div class="bg-light d-flex flex-row">
			<div class="font-weight-bold">&nbsp;GIA:&nbsp;</div>
			<div id="demo_gia">---</div>
		</div>

	</div>
</div>



<script>

    xmlhttp = new XMLHttpRequest();
	
	<?php
		// (A) THIS IS PHP
		$first =  $_GET['_cep'];
	?>
	<?php
		// (B) USE PHP TO ECHO JAVASCRIPT 
		echo "var first = '$first';";
	?>
		
		
    
    //21843794
    //01001000
    xmlhttp.open("GET", 
    	"https://viacep.com.br/ws/"+first+"/xml/", false);
    xmlhttp.send();
    xmlDoc = xmlhttp.responseXML;
   
    document.write("<table border='1'>");
  
    let x = xmlDoc.getElementsByTagName("xmlcep");
    
  

   
    for (let i = 0; i < x.length; i++){
      
      


      



      document.getElementById("demo_logradouro").innerText = x[i].getElementsByTagName("logradouro")[0].childNodes[0].nodeValue;
  		  document.getElementById("demo_logradouro_tela").innerText = x[i].getElementsByTagName("logradouro")[0].childNodes[0].nodeValue;
 


  		 document.getElementById("demo_cep_tela").innerText = x[i].getElementsByTagName("cep")[0].childNodes[0].nodeValue;
  		 document.getElementById("demo_cep").innerText = x[i].getElementsByTagName("cep")[0].childNodes[0].nodeValue;

  		 document.getElementById("demo_bairro").innerText = x[i].getElementsByTagName("bairro")[0].childNodes[0].nodeValue;
  		  
  		

 		document.getElementById("demo_localidade").innerText = x[i].getElementsByTagName("localidade")[0].childNodes[0].nodeValue;

 		document.getElementById("demo_ddd").innerText = x[i].getElementsByTagName("ddd")[0].childNodes[0].nodeValue;
 		document.getElementById("demo_ibge").innerText = x[i].getElementsByTagName("ibge")[0].childNodes[0].nodeValue;
 			
 		document.getElementById("demo_uf_tela").innerText = x[i].getElementsByTagName("uf")[0].childNodes[0].nodeValue;
   


	if(document.getElementsByTagName("complemento").length>0){
      	document.getElementById("demo_complemento").innerText = 
      	"texto";
      	
      }else{
      	document.getElementById("demo_complemento").innerText = x[i].getElementsByTagName("complemento")[0].childNodes[0].nodeValue;
      }


	if(document.getElementsByTagName("gia").length>0){
      	document.getElementById("demo_gia").innerText = 
      	"texto";
      	
      }else{
      	document.getElementById("demo_gia").innerText = x[i].getElementsByTagName("gia")[0].childNodes[0].nodeValue;
      }


    }
  

</script>

















<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	</body>
</html>